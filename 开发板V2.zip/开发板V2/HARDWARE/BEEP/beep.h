#ifndef __BEEP_H
#define __BEEP_H	 
#include "sys.h" 

#define BEEP PDout(5)	// LED����IO

typedef enum {BEEP_ON = 0, BEEP_OFF = !BEEP_ON} BeepState; 



// ***************GPIO_KEY***************************************//	

#define BEEP_PORT    				GPIOD		              	/* GPIO�˿�  ������������*/
#define BEEP_CLK 	    			RCC_AHB1Periph_GPIOD		/* GPIO�˿�ʱ�� */
#define BEEP_PIN						GPIO_Pin_5			        /* GPIO ����*/

// ***********************************************************//	

void BEEP_init(void);
void beep_on(void);


#endif
