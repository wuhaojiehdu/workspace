#include "beep.h"
#include "delay.h" 



void BEEP_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

  RCC_AHB1PeriphClockCmd(BEEP_CLK,ENABLE);//ʹ��GPIOA,GPIOEʱ��
	GPIO_InitStructure.GPIO_Pin = BEEP_PIN; //KEY0 KEY1 KEY2��Ӧ����
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//���� 
  GPIO_Init(BEEP_PORT, &GPIO_InitStructure);//��ʼ��GPIOE2,3,4
}

void beep_on(void)
{
	u32 i;
	for(i=0;i<100;i++)
		{
			BEEP = !BEEP;
			delay_ms(1);
		}




}