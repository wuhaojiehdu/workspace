#include "function.h"


void TFT_LCD_init(void)
{
	 Lcd_Init();			//��ʼ��OLED  
	 LCD_Clear(WHITE);
	 BACK_COLOR=WHITE;
	 OLED_BLK_Set();
	 LCD_ShowChinese(10,0,0,32,RED);   //��

}


void system_init(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	delay_init(168);
	uart_init(115200);
	printf("����ʼ��\r\n");
	BEEP_init();
	if (BEEP_STATE==1){beep_on();}

	TFT_LCD_init();
	LED_init();
	KEY_Init();
	HC138_init();
  GPIO_595_init();
	//��ʱ��ʱ��84M����Ƶϵ��8400������84M/8400=10Khz�ļ���Ƶ�ʣ�����5000��Ϊ500ms
	TPAD_Init(8);
	W25QXX_Init();			//W25QXX��ʼ��
	//Check_W25Q128();
	Adc_Init(); 				//adc��ʼ��
	//CAN1_Mode_Init(CAN_SJW_1tq,CAN_BS2_6tq,CAN_BS1_7tq,6,CAN_Mode_Normal  );
	uart6_init(115200);
	
}


void Led_Test(void)
{
	unsigned char flag = 1;
	while(1)
	{
		switch(flag)
		{
			case 1: LED1 = LED_ON; 	LED2 = LED_OFF; LED3 = LED_OFF; LED4 = LED_OFF; 
							LED5 = LED_OFF; LED6 = LED_OFF; LED7 = LED_OFF; LED8 = LED_OFF;  break;
			
			case 2: LED1 = LED_OFF; LED2 = LED_ON; 	LED3 = LED_OFF; LED4 = LED_OFF; 
							LED5 = LED_OFF; LED6 = LED_OFF; LED7 = LED_OFF; LED8 = LED_OFF;  break;
			
			case 3: LED1 = LED_OFF; LED2 = LED_OFF; LED3 = LED_ON; LED4 = LED_OFF; 
							LED5 = LED_OFF; LED6 = LED_OFF; LED7 = LED_OFF; LED8 = LED_OFF;  break;
			
			case 4: LED1 = LED_OFF; LED2 = LED_OFF; LED3 = LED_OFF; LED4 = LED_ON; 
							LED5 = LED_OFF; LED6 = LED_OFF; LED7 = LED_OFF; LED8 = LED_OFF;  break;
			
			case 5: LED1 = LED_OFF; LED2 = LED_OFF; LED3 = LED_OFF; LED4 = LED_OFF; 
							LED5 = LED_ON; LED6 = LED_OFF; LED7 = LED_OFF; LED8 = LED_OFF;  break;
			
			case 6: LED1 = LED_OFF; LED2 = LED_OFF; LED3 = LED_OFF; LED4 = LED_OFF; 
							LED5 = LED_OFF; LED6 = LED_ON; 	LED7 = LED_OFF; LED8 = LED_OFF;  break;
			
			case 7: LED1 = LED_OFF; LED2 = LED_OFF; LED3 = LED_OFF; LED4 = LED_OFF; 
							LED5 = LED_OFF; LED6 = LED_OFF; LED7 = LED_ON; 	LED8 = LED_OFF;  break;
			
			case 8: LED1 = LED_OFF; LED2 = LED_OFF; LED3 = LED_OFF; LED4 = LED_OFF; 
							LED5 = LED_OFF; LED6 = LED_OFF; LED7 = LED_OFF; LED8 = LED_ON;  break;		
		}
		if(flag<8)flag++;
			else flag = 1; 
		delay_ms(500);
	
	}	
}		
void Key_Test(void)
{
	
	
	unsigned char 	key = 0;
	unsigned char   text[20];
		 LCD_Clear(WHITE);
	while (1)
	{
		key = KEY_Scan(0);
		if(key != 0)
		{	
		sprintf(text,"key = %d",key );
		LCD_ShowString( 10,10,text,RED);		
		}
	}	
}
void Display_Num_Test(void)
{
	
	
	TIM7_Int_Init(5-1,840-1);
	while(1)
	{
	}
}	


void Tpad_Test(void)
{

		if(TPAD_Scan(0))	//�ɹ�������һ��������(�˺���ִ��ʱ������15ms)
		{
			LED3=!LED3;		//LED1ȡ��
		
		}
}
void Check_W25Q128(void)
{

	u8 i = 3;
	while(W25QXX_ReadID()==W25Q128)								//��ⲻ��W25Q128
	{
		do
		{
		LED8=!LED8;	
		delay_ms(200);
	  LED8=!LED8;		//DS0��˸
		delay_ms(200);
		i--;
		}while (i);
		break;
	}
}


void Can_Test(void)
{
		u8 canbuf_tx[8] = {0X0F, 0X3F,0X10,0X88,0XFF, 0X3F,0X10,0X88};
		u8 canbuf_rx[8];
		CAN1_Send_Msg(canbuf_tx,8);
		


}

void Adc_Test(void)
{
	unsigned char   text[20];
	u16 adcx;
	while(1)
	{
	adcx=Get_Adc(ADC_Channel_1);
	sprintf(text,"ADC_VALUE = %4d",adcx );
	LCD_ShowString( 10,10,text,RED);	
	printf(text);
	delay_ms(1);
	 //LCD_Clear(WHITE);
	}

}

void Ds18b20_Test(void)
{
	float temperature;
	while(DS18B20_Init())	//DS18B20��ʼ��	
	{
		LED1 = LED_ON;
		delay_ms(200);
	}
	
	LED1 = LED_OFF;
	temperature=DS18B20_Get_Temp();	
	temperature = temperature/10;
	 printf("�£� %f \r\n",(temperature));
	delay_ms(10);

}

void Dac_Test(void)
{

	sin_Generation();	//  DAC ���Ҳ�����
	GPIO_Configuration();
	TIM6_Configuration();
	DAC_DMA_Configuration();  
	while(1);
}



void Wifi_Test(void)
{
	u6_printf("AT\r\n");
	while(1);
}

void Hc05_Test(void)
{
	uart2_init(38400);  //38400 ΪATָ������ģʽ
	u2_printf("AT\r\n");
	while(1);
}


void Gpio_Test(void)
{
		GPIO_InitTypeDef  GPIO_InitStructure;
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB|RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOC, ENABLE);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_6;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;//��ͨ���ģʽ
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;//�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;//100MHz
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;//����
  GPIO_Init(GPIOB,&GPIO_InitStructure);//��ʼ��GPIO

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_0;
	GPIO_Init(GPIOC,&GPIO_InitStructure);//��ʼ��GPIO
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
	GPIO_Init(GPIOA,&GPIO_InitStructure);//��ʼ��GPIO
	
	GPIO_ResetBits(GPIOB,GPIO_Pin_6);
//	
	GPIO_ResetBits(GPIOB,GPIO_Pin_7);
	
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	GPIO_SetBits(GPIOC,GPIO_Pin_0);
	while(1);

}

void Test(void)
{
	unsigned char 	key = 0;
	unsigned char   text[20];
	LCD_Clear(WHITE);
	sprintf(text,"key = 1 adc_test" );
	LCD_ShowString( 10,10,text,RED);
	while (1)
	{
		key = KEY_Scan(0);
		if(key != 0 )
		{	
			if(key = K_A )
			{
			
			}
			if(key = K_UP)
			{
			
			
			}
		}
	}	


}


