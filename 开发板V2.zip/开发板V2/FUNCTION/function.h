#ifndef __FUNCTION_H
#define __FUNCTION_H

#include "stm32f4xx.h"
#include "usart.h"
#include "delay.h"
#include "oled.h"
#include "led.h"
#include "key.h"
#include "timer.h"
#include "beep.h"
#include "tpad.h"
#include "spi.h"
#include "w25qxx.h"
#include "can.h"
#include "adc.h"
#include "ds18b20.h"
#include "dac.h"
#include "wifi.h"
#include "hc05.h"

#define BEEP_STATE 0


void system_init(void);
void TFT_LCD_init(void);
void Led_Test(void);
void Key_Test(void);
void Display_Num_Test(void);
void Tpad_Test(void);
void Check_W25Q128(void);
void Can_Test(void);
void Adc_Test(void);
void Ds18b20_Test(void);
void Dac_Test(void);
void Wifi_Test(void);
void Hc05_Test(void);
void Gpio_Test(void);
void Test(void);
#endif

